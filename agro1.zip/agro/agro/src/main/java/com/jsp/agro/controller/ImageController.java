package com.jsp.agro.controller;


import java.io.IOException;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.multipart.MultipartFile;
import com.jsp.agro.dao.ImageDao;
import com.jsp.agro.entity.Image;
import com.jsp.agro.service.ImageService;
import com.jsp.agro.util.ResponseStructure;

@RestController
public class ImageController {
	@Autowired
	private ImageService service;
	@Autowired
	private ImageDao dao;
	
	 @PostMapping("/saveimage")
	 public ResponseEntity<ResponseStructure<Image>> saveImage( @RequestParam int user_id , @RequestParam("file") MultipartFile file, @RequestParam("name") String name)throws IOException {
	  return service.saveImage(user_id, name, file);
	 }
	 
	 @GetMapping("/image")
     public ResponseEntity<byte[]> getImage(@RequestParam int id) {
         byte[] imageBytes = dao.fetchPhoto(id).getImage();

         // Set appropriate content type (e.g., image/jpeg)
         HttpHeaders headers = new HttpHeaders();
         headers.setContentType(MediaType.IMAGE_JPEG);
         return new ResponseEntity<>(imageBytes, headers, HttpStatus.OK);
     }
     
     @PutMapping("/updateimg")
     public ResponseEntity<ResponseStructure<Image>> updateImage(@RequestParam("image")MultipartFile file,@RequestParam int id) throws Exception{
		return service.updateImage(id, file);
     }
     
     @DeleteMapping("/deleteimg")
     public ResponseEntity<ResponseStructure<Image>> deleteImage(@RequestParam int id){
		return service.deleteIamge(id);
    	 
     }

}
