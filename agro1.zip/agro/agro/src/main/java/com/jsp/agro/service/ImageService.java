package com.jsp.agro.service;

import java.io.IOException;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;
import org.springframework.web.multipart.MultipartFile;

import com.jsp.agro.dao.ImageDao;
import com.jsp.agro.dao.UserDao;
import com.jsp.agro.entity.Image;
import com.jsp.agro.entity.User;
import com.jsp.agro.exception.ImageNotFound;
import com.jsp.agro.exception.UserNotFound;
import com.jsp.agro.repo.ImageRepo;
import com.jsp.agro.util.ResponseStructure;

@Service
public class ImageService {
	
	@Autowired
	private ImageDao idao;
	@Autowired
	private UserDao userdao;
	
	public ResponseEntity<ResponseStructure<Image>> saveImage(int uid, String name, MultipartFile file) throws IOException {
		  User db = userdao.fetchById(uid);
		  if(db!=null) {
		   Image img=new Image();
		   img.setName(name);
		   img.setImage(file.getBytes());
		   Image imgdb = idao.saveImage(img);
		   db.setProfile(imgdb);
		   userdao.updateUser(db);
		   ResponseStructure<Image> rs=new ResponseStructure<Image>();
		   rs.setData(imgdb);
		   rs.setMsg("Image saved succeesfully");
		   rs.setStatusCode(HttpStatus.ACCEPTED.value());
		   return new ResponseEntity<ResponseStructure<Image>>(rs,HttpStatus.ACCEPTED);
		  }
		  else{
		   throw new UserNotFound("user not found");
		  }
		 }
	
	public ResponseEntity<ResponseStructure<Image>> fetchPhoto(int id) {
		ResponseStructure<Image> rs = new ResponseStructure<Image>();
		Image db = idao.fetchPhoto(id);
		if(db != null) {
			rs.setData(idao.fetchPhoto(id));
			rs.setMsg("image fetched successfully");
			rs.setStatusCode(HttpStatus.FOUND.value());
			return new ResponseEntity<ResponseStructure<Image>>(rs, HttpStatus.FOUND);
		}
		throw new ImageNotFound("image not found for given id"+ id) ;
	}
	
	public ResponseEntity<ResponseStructure<Image>> updateImage(int id, MultipartFile file)throws Exception{
		ResponseStructure<Image> rs = new ResponseStructure<Image>();
		Image db = idao.fetchPhoto(id);
		if(db != null) {
			db.setImage(file.getBytes());
			db.setName(file.getOriginalFilename());
			Image i = idao.updateImage(db);
			rs.setData(i);
			rs.setMsg("image updated successfully");
			rs.setStatusCode(HttpStatus.FOUND.value());
			return new ResponseEntity<ResponseStructure<Image>>(rs, HttpStatus.FOUND);
		}
		throw new ImageNotFound("Image not found for the given id"+ id);
	}
	
	public ResponseEntity<ResponseStructure<Image>> deleteIamge(int id){
		ResponseStructure<Image> rs = new ResponseStructure<Image>();
		Image db = idao.fetchPhoto(id);
		if(db != null) {
			User udb = userdao.fetchUserByImage(db);
			udb.setProfile(null);
			userdao.updateUser(udb);
			idao.deleteImage(id);
			rs.setData(db);
			rs.setMsg("image deleted");
			rs.setStatusCode(HttpStatus.FOUND.value());
			return new ResponseEntity<ResponseStructure<Image>>(rs, HttpStatus.FOUND);
		}
		throw new ImageNotFound("Image not found for the given Id"+ id);
	}
	
	
}
