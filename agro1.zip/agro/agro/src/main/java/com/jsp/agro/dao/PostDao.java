package com.jsp.agro.dao;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import com.jsp.agro.entity.Post;
import com.jsp.agro.repo.PostRepo;

@Repository
public class PostDao {
	@Autowired
	private PostRepo repo;

	@Autowired
	private ImageDao profiledao;

	@Autowired
	private CommentDao cmtDao;

	public Post savePost(Post post) {
		return repo.save(post);
	}

	public Post updatePost(Post post) {
		Optional<Post> opt = repo.findById(post.getId());
		if (opt.isPresent()) {
			Post p = opt.get();
			if (post.getLikes() == 0) {
				post.setLikes(p.getLikes());
			}
			if (post.getCaption() == null) {
				post.setCaption(p.getCaption());
			}
			if (post.getComment() == null) {
				post.setComment(p.getComment());
			}
			if (post.getDate() == null) {
				post.setDate(p.getDate());
			}
			if (post.getTime() == null) {
				post.setTime(p.getTime());
			}
			if (post.getLocation() == null) {
				post.setLocation(p.getLocation());
			}
			if (post.getImage() == null) {
				post.setImage(p.getImage());
			} else {
				post.setImage(profiledao.updateImage(p.getImage()));
			}
			return repo.save(post);
		} else {
			return null;
		}
	}

	public Post fetchPostById(int id) {
		Optional<Post> opt = repo.findById(id);
		if (opt.isPresent()) {
			return opt.get();
		} else {
			return null;
		}
	}

	public Post deletePost(int id) {
		Optional<Post> opt = repo.findById(id);
		if (opt.isPresent()) {
			repo.deleteById(id);
			return opt.get();
		} else {
			return null;
		}
	}

	public List<Post> allPosts() {
		return repo.findAll();
	}

}
