package com.jsp.agro.exception;

import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.bind.annotation.RestControllerAdvice;

import com.jsp.agro.util.ResponseStructure;

@RestControllerAdvice
public class EquipmentExceptionHandler {
	@ExceptionHandler(EquipmentNotFound.class)
	public ResponseEntity<ResponseStructure<String>> equipmentNotFound(EquipmentNotFound enf){
		ResponseStructure<String> rs = new ResponseStructure<String>();
		rs.setData(enf.getMsg());
		rs.setMsg("equipment not found");
		rs.setStatusCode(HttpStatus.NOT_FOUND.value());
		return new ResponseEntity<ResponseStructure<String>>(rs,HttpStatus.NOT_FOUND);
	}
}
