package com.jsp.agro.entity;

import java.util.List;

import org.hibernate.annotations.Cascade;
import org.hibernate.annotations.CascadeType;

import com.jsp.agro.enums.UserType;
import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.OneToMany;
import jakarta.persistence.OneToOne;
import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.NotNull;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Entity
@Data
@AllArgsConstructor
@NoArgsConstructor
public class User {
	
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private int id;
	@NotBlank(message = "firstname cannot be blank")
	@NotNull(message = "firstname cannot be null")
	private String firstName;
	@NotBlank(message = "lastname cannot be blank")
	@NotNull(message = "lastname cannot be null")
	private String lastName;
	@Column(unique = true)
	private String email;
	private long phone;
	private String password;
	private String gender;
	private int age;
	private UserType type;
	@OneToOne
	@Cascade(CascadeType.ALL)
	private Address address;
	@OneToOne
	@Cascade(CascadeType.ALL)
	private Image profile;
	@OneToMany
	@Cascade(CascadeType.ALL)
	private List<Post> post;
}
