package com.jsp.agro.dao;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import com.jsp.agro.entity.Image;
import com.jsp.agro.repo.ImageRepo;

@Repository
public class ImageDao {
	@Autowired
	private ImageRepo repo;
	
	public Image saveImage(Image profile) {
		return repo.save(profile);
	}
	
	public Image fetchPhoto(int id) {
		Optional<Image> db = repo.findById(id);
		if(db.isPresent()) {
			return db.get();
		}else {
			return null;
		}
	}
	
	public Image updateImage(Image image) {
		Optional<Image> opt = repo.findById(image.getId());
		if(opt.isPresent()) {
			Image db = opt.get();
//			if(image.getId()==0) {
//				image.setId(db.getId());
//			}
			if(image.getName()==null) {
				image.setName(db.getName());
			}
			if(image.getImage()==null) {
				image.setImage(db.getImage());
			}
			return repo.save(image);
		}else {
			return null;
		}
	}
	
	public Image deleteImage(int id) {
		Optional<Image> opt = repo.findById(id);
		if(opt.isPresent()) {
			
			repo.deleteById(id);
			return opt.get();
		}else {
			return null;
		}
	}
	
	public List<Image> fetchAllProfiles(){
		return repo.findAll();
	}

}
