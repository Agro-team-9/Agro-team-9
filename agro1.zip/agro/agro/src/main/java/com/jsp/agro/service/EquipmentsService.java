package com.jsp.agro.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;

import com.jsp.agro.dao.EquipmentsDao;
import com.jsp.agro.dao.UserDao;
import com.jsp.agro.entity.Equipments;
import com.jsp.agro.entity.User;
import com.jsp.agro.exception.EquipmentNotFound;
import com.jsp.agro.exception.UserNotFound;
import com.jsp.agro.util.ResponseStructure;

@Service
public class EquipmentsService {
	
	@Autowired
	private EquipmentsDao edao;
	@Autowired
	private UserDao udao;
	
	public ResponseEntity<ResponseStructure<Equipments>> saveEquipments(int uid,String Ename,double costperhr,int quantity){
		User udb = udao.fetchById(uid);
		if(udb!=null) {
			Equipments equip = new Equipments();
			equip.setEname(Ename);
			equip.setCostperhr(costperhr);
			equip.setQuantity(quantity);
			equip.setUser(udb);
			Equipments edb = edao.saveEquipment(equip);
			ResponseStructure<Equipments> rs = new ResponseStructure<Equipments>();
			rs.setData(edb);
			rs.setMsg("equipment added");
			rs.setStatusCode(HttpStatus.OK.value());
			return new ResponseEntity<ResponseStructure<Equipments>>(rs,HttpStatus.OK);
		}
		else {
			throw new UserNotFound("user not found for your search:"+uid);
		}
	}
	
	public ResponseEntity<ResponseStructure<Equipments>> fetchById(int id){
		Equipments edb = edao.fetchByID(id);
		if(edb!=null) {
			ResponseStructure<Equipments> rs = new ResponseStructure<Equipments>();
			rs.setData(edb);
			rs.setMsg("equipment found successfullu");
			rs.setStatusCode(HttpStatus.FOUND.value());
			return new ResponseEntity<ResponseStructure<Equipments>>(rs,HttpStatus.FOUND);
		}
		else {
			throw new EquipmentNotFound("equipment not found for your search:"+id);
		}
	}
	
	public ResponseEntity<ResponseStructure<List<Equipments>>> fetchEquipmentByName(String Ename){
		List<Equipments> edb = edao.fetchEquipmentByName(Ename);
		if(edb!=null) {
			ResponseStructure<List<Equipments>> rs = new ResponseStructure<List<Equipments>>();
			rs.setData(edb);
			rs.setMsg("equipment found successfully");
			rs.setStatusCode(HttpStatus.FOUND.value());
			return new ResponseEntity<ResponseStructure<List<Equipments>>>(rs,HttpStatus.FOUND);
		}
		else {
			throw new EquipmentNotFound("No equipment for your search:"+Ename);
		}
	}
	
	public ResponseEntity<ResponseStructure<List<Equipments>>> fetchAllEquipment(){
		List<Equipments> edb = edao.fetchAll();
		if(edb!=null) {
			ResponseStructure<List<Equipments>> rs = new ResponseStructure<List<Equipments>>();
			rs.setData(edb);
			rs.setMsg("all equipments fetched successfully");
			rs.setStatusCode(HttpStatus.FOUND.value());
			return new ResponseEntity<ResponseStructure<List<Equipments>>>(rs,HttpStatus.FOUND);
		}
		else {
			throw new EquipmentNotFound("No equipment for your search:");
		}
	}
	
	public ResponseEntity<ResponseStructure<List<Equipments>>> fetchEquipmentByUser(int user_id){
		User udb = udao.fetchById(user_id);
		if(udb!=null) {
			List<Equipments> edb = edao.fetchEquipmentByUser(udb);
			ResponseStructure<List<Equipments>> rs = new ResponseStructure<List<Equipments>>();
			rs.setData(edb);
			rs.setMsg("user equipments fetched successfully");
			rs.setStatusCode(HttpStatus.FOUND.value());
			return new ResponseEntity<ResponseStructure<List<Equipments>>>(rs,HttpStatus.FOUND);
		}
		else {
			throw new UserNotFound("No user for your search:"+user_id);
		}
	}
	
	public ResponseEntity<ResponseStructure<Equipments>> updateEquipment(Equipments equipments){
		Equipments edb = edao.fetchByID(equipments.getId());
		if(edb!=null) {
			ResponseStructure<Equipments> rs = new ResponseStructure<Equipments>();
			rs.setData(edao.updateEquipments(equipments));
			rs.setMsg("equipments detalis updated");
			rs.setStatusCode(HttpStatus.FOUND.value());
			return new ResponseEntity<ResponseStructure<Equipments>>(rs,HttpStatus.FOUND);
		}
		else {
			throw new EquipmentNotFound("Equipment Not found for your search:"+equipments.getId());
		}
	}
	
	public ResponseEntity<ResponseStructure<Equipments>> deleteEquipments(int id){
		User udb = udao.fetchById(id);
		if(udb!=null) {
			Equipments edb = edao.deleteEquipmentsByID(id);
			edb.setUser(null);
			edao.deleteEquipmentsByID(id);
			ResponseStructure<Equipments> rs = new ResponseStructure<Equipments>();
			rs.setData(edb);
			rs.setMsg("Equipment deleted");
			rs.setStatusCode(HttpStatus.FOUND.value());
			return new ResponseEntity<ResponseStructure<Equipments>>(rs,HttpStatus.FOUND);
		}
		else {
			throw new EquipmentNotFound("Equipment not found for your search:"+id);
		}
	}
}
