package com.jsp.agro.dao;


import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import com.jsp.agro.entity.Comment;
import com.jsp.agro.repo.CommentRepo;

@Repository
public class CommentDao {
	@Autowired
	private CommentRepo repo;

	@Autowired
	private UserDao userDao;

	public Comment saveComment(Comment comment) {
		return repo.save(comment);
	}

	public Comment updateComment(Comment comment) {
		Optional<Comment> opt = repo.findById(comment.getId());
		if (opt.isPresent()) {
			Comment db = opt.get();
			if (comment.getComment() == null) {
				comment.setComment(db.getComment());
			}
			if (comment.getUser() == null) {
				comment.setComment(db.getComment());
			} else {
				comment.setUser(userDao.updateUser(comment.getUser()));
			}
			return repo.save(comment);
		} else {
			return null;
		}
	}

	public Comment fetchComment(int id) {
		Optional<Comment> opt = repo.findById(id);
		if (opt.isPresent()) {
			return opt.get();
		} else {
			return null;
		}
	}

	public Comment deleteComment(int id) {
		Optional<Comment> opt = repo.findById(id);
		if (opt.isPresent()) {
			repo.deleteById(id);
			return opt.get();
		} else {
			return null;
		}
	}
}
