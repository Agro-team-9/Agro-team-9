package com.jsp.agro.entity;

import java.sql.Date;
import java.sql.Time;
import java.util.List;

import org.hibernate.annotations.Cascade;
import org.hibernate.annotations.CascadeType;

import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.OneToMany;
import jakarta.persistence.OneToOne;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Entity
@Data
@AllArgsConstructor
@NoArgsConstructor
public class Post {
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private int id;
	@OneToOne
	@Cascade(CascadeType.ALL)
	private Image image;
	private int likes;
	@OneToMany
	@Cascade(CascadeType.ALL)
	private List<Comment> comment;
	private Date date;
	private Time time;
	private String caption;
	private String location;
}
