package com.jsp.agro.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.jsp.agro.entity.Equipments;
import com.jsp.agro.service.EquipmentsService;
import com.jsp.agro.util.ResponseStructure;

@RestController
public class EquipmentsController {
	@Autowired
	private EquipmentsService service;
	
	@PostMapping("/ep")
	public ResponseEntity<ResponseStructure<Equipments>> saveEquipments(@RequestParam int id,@RequestParam String Ename,@RequestParam double costperhr,@RequestParam int quantity){
		return service.saveEquipments(id, Ename, costperhr, quantity);
	}
	
	@GetMapping("/ep")
	public ResponseEntity<ResponseStructure<Equipments>> fetchById(@RequestParam int id){
		return service.fetchById(id);
	}
	
	@GetMapping("/epn")
	public ResponseEntity<ResponseStructure<List<Equipments>>> fetchEquipmentByName(@RequestParam String Ename){
		System.out.println("Controller"+Ename);
		return service.fetchEquipmentByName(Ename);
	}
	
	@GetMapping("/epa")
	public ResponseEntity<ResponseStructure<List<Equipments>>> fetchAllEquipment(){
		return service.fetchAllEquipment();
	}
	
	@GetMapping("/equ")
	public ResponseEntity<ResponseStructure<List<Equipments>>> fetchEquipmentByUser(@RequestParam int user_id){
		return service.fetchEquipmentByUser(user_id);
	}
	
	@PutMapping("/eq")
	public ResponseEntity<ResponseStructure<Equipments>> updateEquipment(@RequestBody Equipments equipments){
		return service.updateEquipment(equipments);
	}
	
	@DeleteMapping("/eq")
	public ResponseEntity<ResponseStructure<Equipments>> deleteEquipment(@RequestParam int id){
		return service.deleteEquipments(id);
	}
}
