package com.jsp.agro.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.multipart.MultipartFile;

import com.jsp.agro.entity.Post;
import com.jsp.agro.service.PostService;
import com.jsp.agro.util.ResponseStructure;

@RestController
public class PostController {
	@Autowired
	private PostService service;
	
	@PostMapping("/ps")
	public ResponseEntity<ResponseStructure<Post>> savePost(@RequestParam int id,@RequestParam String location,@RequestParam String caption,@RequestParam ("image") MultipartFile file) throws Exception {
		return service.savePost(id, file, caption, location);
	}
	
	@GetMapping("/ps")
	public ResponseEntity<ResponseStructure<Post>> fetchPostById(@RequestParam int id){
		return service.fetchByID(id);
	}
	
	@DeleteMapping("/ps")
	public ResponseEntity<ResponseStructure<Post>> delete(@RequestParam int id){
		return service.deletePost(id);
	}
}
