package com.jsp.agro.dao;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import com.jsp.agro.entity.Address;
import com.jsp.agro.repo.AddressRepo;

@Repository
public class AddressDao {

	@Autowired
	private AddressRepo repo;

	public Address saveAddress(Address address) {
		return repo.save(address);
	}

	public Address fetchById(int id) {
		Optional<Address> opt = repo.findById(id);
		if (opt.isPresent()) {
			return opt.get();
		} else {
			return null;
		}
	}

	public Address updateAddress(Address address) {
		Optional<Address> opt = repo.findById(address.getId());
		if (opt.isPresent()) {
			Address db = opt.get();
			if (address.getId() == 0) {
				address.setId(db.getId());
			}
			if (address.getHouseNum() == null) {
				address.setHouseNum(db.getHouseNum());
			}
			if (address.getStreet() == null) {
				address.setStreet(db.getStreet());
			}
			if (address.getLandMark() == null) {
				address.setLandMark(db.getLandMark());
			}
			if (address.getMandal() == null) {
				address.setMandal(db.getMandal());
			}
			if (address.getDistrict() == null) {
				address.setDistrict(db.getDistrict());
			}
			if (address.getState() == null) {
				address.setState(db.getState());
			}
			if (address.getPinCode() == 0) {
				address.setPinCode(db.getPinCode());
			}
			return repo.save(address);
		} else {
			return null;
		}
	}

	public Address deleteBYId(int id) {
		Optional<Address> opt = repo.findById(id);
		if (opt.isPresent()) {
			repo.deleteById(id);
			return opt.get();
		} else {
			return null;
		}
	}

	public List<Address> fetchAllAddresses() {
		return repo.findAll();
	}

}
