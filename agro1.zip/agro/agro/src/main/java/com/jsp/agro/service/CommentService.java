package com.jsp.agro.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;

import com.jsp.agro.dao.CommentDao;
import com.jsp.agro.dao.PostDao;
import com.jsp.agro.dao.UserDao;
import com.jsp.agro.entity.Comment;
import com.jsp.agro.entity.Post;
import com.jsp.agro.entity.User;
import com.jsp.agro.exception.CommentNotFound;
import com.jsp.agro.exception.PostNotFound;
import com.jsp.agro.exception.UserNotFound;
import com.jsp.agro.util.ResponseStructure;

@Service
public class CommentService {
	
	@Autowired
	private CommentDao cdao;
	
	@Autowired
	private PostDao pdao;
	
	@Autowired
	private UserDao udao;
	
	public ResponseEntity<ResponseStructure<Comment>> saveComment(int pid,int uid,String comment){
		Post post = pdao.fetchPostById(pid);
		if(post!=null) {
			User udb = udao.fetchById(uid);
			if(udb!=null) {
				Comment c = new Comment();
				c.setComment(comment);
				c.setUser(udb);
				Comment cdb = cdao.saveComment(c);
				List<Comment> list = post.getComment();
				list .add(cdb);
				post.setComment(list);
				pdao.updatePost(post);
				ResponseStructure<Comment> s = new ResponseStructure<Comment>();
				s.setData(cdb);
				s.setMsg("Commented success");
				s.setStatusCode(HttpStatus.ACCEPTED.value());
				return new ResponseEntity<ResponseStructure<Comment>>(s,HttpStatus.ACCEPTED);
			}
			else {
				throw new UserNotFound("User not found for your serch:"+uid);
			}
		}
		else {
			throw new PostNotFound("post not found for your seach:"+pid);
		}
	}
	public ResponseEntity<ResponseStructure<Comment>> deleteComment(int id){
		 Comment c = cdao.fetchComment(id);
		 if(c!=null) {
			 List<Post> p = pdao.allPosts();
			 for(Post post :  p) {
				 List<Comment> co = post.getComment();
				 if(co.contains(c)) {
					 co.remove(c);
					 pdao.updatePost(post);
					 cdao.deleteComment(id);
					 break;
				 }
			 }
			 ResponseStructure<Comment> s= new ResponseStructure<Comment>();
			 s.setData(c);
			 s.setMsg("Comment deleted");
			 s.setStatusCode(HttpStatus.OK.value());
			 return new ResponseEntity<ResponseStructure<Comment>>(s,HttpStatus.OK);
		 }
		 else {
			 throw new CommentNotFound("Comment not found for your search:"+id);
		 }
	}
}
