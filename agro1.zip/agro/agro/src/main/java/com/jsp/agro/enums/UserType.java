package com.jsp.agro.enums;

import jakarta.persistence.Enumerated;


public enum UserType {
	@Enumerated
	farmer

}
