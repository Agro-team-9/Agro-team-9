package com.jsp.agro.exception;

import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.bind.annotation.RestControllerAdvice;
import com.jsp.agro.util.ResponseStructure;

@RestControllerAdvice
public class ExceptionHandlerForUser {
	
	@ExceptionHandler(UserNotFound.class)
	public ResponseEntity<ResponseStructure<String>> user(UserNotFound user){
		ResponseStructure<String> rs=new ResponseStructure<String>();
		rs.setData(user.getMsg());
		rs.setMsg("user not found");
		rs.setStatusCode(HttpStatus.NOT_FOUND.value());
		return new ResponseEntity<ResponseStructure<String>>(rs,HttpStatus.NOT_FOUND);
	}
	
	@ExceptionHandler(EmailWrong.class)
	public ResponseEntity<ResponseStructure<String>> user(EmailWrong email){
		ResponseStructure<String> rs=new ResponseStructure<String>();
		rs.setData(email.getMsg());
		rs.setMsg("Email not found");
		rs.setStatusCode(HttpStatus.NOT_FOUND.value());
		return new ResponseEntity<ResponseStructure<String>>(rs,HttpStatus.NOT_FOUND);
	}
	
	@ExceptionHandler(WrongPassword.class)
	public ResponseEntity<ResponseStructure<String>> user(WrongPassword password){
		ResponseStructure<String> rs=new ResponseStructure<String>();
		rs.setData(password.getMsg());
		rs.setMsg("You have entered wrong password");
		rs.setStatusCode(HttpStatus.NOT_FOUND.value());
		return new ResponseEntity<ResponseStructure<String>>(rs,HttpStatus.NOT_FOUND);
	}

}
