package com.jsp.agro.enums;

public enum UserType {
	
	farmer

}
