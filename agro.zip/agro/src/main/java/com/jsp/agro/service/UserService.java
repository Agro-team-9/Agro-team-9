package com.jsp.agro.service;

import java.util.List;
import java.util.Random;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.mail.SimpleMailMessage;
import org.springframework.mail.javamail.JavaMailSender;
import org.springframework.stereotype.Service;
import com.jsp.agro.dao.AddressDao;
import com.jsp.agro.dao.UserDao;
import com.jsp.agro.entity.Address;
import com.jsp.agro.entity.User;
import com.jsp.agro.exception.EmailWrong;
import com.jsp.agro.exception.UserNotFound;
import com.jsp.agro.exception.WrongPassword;
import com.jsp.agro.util.ResponseStructure;

@Service
public class UserService {

	@Autowired
	private UserDao userDao;

	@Autowired
	private AddressDao addDao;

	@Autowired
	private JavaMailSender emailSender;

	public ResponseEntity<ResponseStructure<User>> register(User user) {
		ResponseStructure<User> rs = new ResponseStructure<User>();
		rs.setData(userDao.register(user));
		rs.setMsg("Registration Successful");

		SimpleMailMessage mailMessage = new SimpleMailMessage();
		mailMessage.setFrom("arunkangti22@gmail.com");
		mailMessage.setTo(user.getEmail());
		mailMessage.setText("Registration successful");
		mailMessage.setSubject("User Registration");
		emailSender.send(mailMessage);

		rs.setStatusCode(HttpStatus.CREATED.value());
		return new ResponseEntity<ResponseStructure<User>>(rs, HttpStatus.CREATED);
	}

	public ResponseEntity<ResponseStructure<Address>> saveAddress(Address address) {
		ResponseStructure<Address> rs = new ResponseStructure<Address>();
		rs.setData(addDao.saveAddress(address));
		rs.setMsg("Address saved Successfully");
		rs.setStatusCode(HttpStatus.CREATED.value());
		return new ResponseEntity<ResponseStructure<Address>>(rs, HttpStatus.CREATED);
	}

	public ResponseEntity<ResponseStructure<User>> fetchById(int id) {
		ResponseStructure<User> rs = new ResponseStructure<User>();
		User db = userDao.fetchById(id);
		if (db != null) {
			rs.setData(userDao.fetchById(id));
			rs.setMsg("User details fetched Successfully");
			rs.setStatusCode(HttpStatus.FOUND.value());
			return new ResponseEntity<ResponseStructure<User>>(rs, HttpStatus.FOUND);
		} else {
			throw new UserNotFound("User not found for the given id : " + id);
		}
	}

	public ResponseEntity<ResponseStructure<User>> login(String email, String password) {
		ResponseStructure<User> rs = new ResponseStructure<User>();
		User db = userDao.login(email);
		if (db != null) {
			if (db.getPassword().equals(password)) {
				rs.setData(userDao.login(email));
				rs.setMsg("Login Successful");
				rs.setStatusCode(HttpStatus.FOUND.value());
				return new ResponseEntity<ResponseStructure<User>>(rs, HttpStatus.FOUND);
			} else {
				throw new WrongPassword("wrong password");
			}
		} else {
			throw new EmailWrong("Email not found : " + email);
		}
	}

	public ResponseEntity<ResponseStructure<User>> deleteById(int id) {
		ResponseStructure<User> rs = new ResponseStructure<User>();
		User db = userDao.fetchById(id);
		if (db != null) {
			rs.setData(userDao.deleteById(id));
			addDao.deleteBYId(db.getAddress().getId());
			rs.setMsg("User Details Deleted Successfully");
			rs.setStatusCode(HttpStatus.FOUND.value());
			return new ResponseEntity<ResponseStructure<User>>(rs, HttpStatus.FOUND);
		} else {
			throw new UserNotFound("User not found for the given id : " + id);
		}
	}

	public ResponseEntity<ResponseStructure<List<User>>> fetchAllUsers() {
		ResponseStructure<List<User>> rs = new ResponseStructure<List<User>>();
		List<User> db = userDao.fetchAll();
		if (db != null) {
			rs.setData(db);
			rs.setMsg("All User's details fetched successfully");
			rs.setStatusCode(HttpStatus.FOUND.value());
			return new ResponseEntity<ResponseStructure<List<User>>>(rs, HttpStatus.FOUND);
		} else {
			throw new UserNotFound("Data base is empty");
		}
	}

	public ResponseEntity<ResponseStructure<User>> updateUser(User user) {
		ResponseStructure<User> rs = new ResponseStructure<User>();
		User db = userDao.fetchById(user.getId());
		if (db != null) {
			rs.setData(userDao.updateUser(user));
			rs.setMsg("User details updated Successful");
			rs.setStatusCode(HttpStatus.FOUND.value());
			return new ResponseEntity<ResponseStructure<User>>(rs, HttpStatus.FOUND);
		} else {
			throw new UserNotFound("User not found for the given id : " + user.getId());
		}
	}

	public ResponseEntity<ResponseStructure<Address>> deleteAddress(int id) {
		ResponseStructure<Address> rs = new ResponseStructure<Address>();
		Address db = addDao.fetchById(id);
		if (db != null) {
			rs.setData(addDao.deleteBYId(id));
			rs.setMsg("Address Details Deleted Successfully");
			rs.setStatusCode(HttpStatus.FOUND.value());
			return new ResponseEntity<ResponseStructure<Address>>(rs, HttpStatus.FOUND);
		} else {
			throw new UserNotFound("Address not found for the given id : " + id);
		}
	}

	public ResponseEntity<ResponseStructure<Integer>> sendOTP(String email) {
		ResponseStructure<Integer> rs = new ResponseStructure<Integer>();
		User db = userDao.login(email);
		if (db != null) {
			Random random = new Random();
			int value = random.nextInt();
			rs.setData(value);
			rs.setMsg("OTP sent successfully");
			rs.setStatusCode(HttpStatus.FOUND.value());
			SimpleMailMessage mailMessage = new SimpleMailMessage();
			mailMessage.setFrom("arunkangti22@gmail.com");
			mailMessage.setTo(email);
			mailMessage.setText("please enter otp : " + value);
			mailMessage.setSubject("OTP verification");
			emailSender.send(mailMessage);
			return new ResponseEntity<ResponseStructure<Integer>>(rs, HttpStatus.FOUND);
		} else {
			return null;
		}
	}

}
