package com.jsp.agro.dao;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import com.jsp.agro.entity.Post;
import com.jsp.agro.repo.PostRepo;

@Repository
public class PostDao {

	@Autowired
	private PostRepo repo;

	@Autowired
	private ProfileDao profiledao;

	@Autowired
	private CommentDao cmtDao;

	public Post savePost(Post post) {
		return repo.save(post);
	}

	public Post updatePost(Post post) {
		Optional<Post> opt = repo.findById(post.getId());
		if (opt.isPresent()) {
			Post db = opt.get();
			if (post.getId() == 0) {
				post.setId(db.getId());
			}
			if (post.getLikes() == 0) {
				post.setLikes(db.getLikes());
			}
			if (post.getCaption() == null) {
				post.setCaption(db.getCaption());
			}
			if (post.getComment() == null) {
				post.setComment(db.getComment());
			} else {
				
			}
			if (post.getDate() == null) {
				post.setDate(db.getDate());
			}
			if (post.getTime() == null) {
				post.setTime(db.getTime());
			}
			if (post.getLocation() == null) {
				post.setLocation(db.getLocation());
			}
			if (post.getImage() == null) {
				post.setImage(db.getImage());
			} else {
				post.setImage(profiledao.updateProfile(db.getImage()));
			}
			return repo.save(post);
		} else {
			return null;
		}
	}

	public Post fetchById(int id) {
		Optional<Post> opt = repo.findById(id);
		if (opt.isPresent()) {
			return opt.get();
		} else {
			return null;
		}
	}

	public Post deletePost(int id) {
		Optional<Post> opt = repo.findById(id);
		if (opt.isPresent()) {
			repo.deleteById(id);
			return opt.get();
		} else {
			return null;
		}
	}

	public List<Post> allPosts() {
		return repo.findAll();
	}

}
