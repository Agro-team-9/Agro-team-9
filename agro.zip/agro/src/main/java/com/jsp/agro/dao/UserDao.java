package com.jsp.agro.dao;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import com.jsp.agro.entity.User;
import com.jsp.agro.repo.UserRepo;

@Repository
public class UserDao {

	@Autowired
	private UserRepo repo;

	@Autowired
	private AddressDao dao;

	public User register(User user) {
		return repo.save(user);
	}

	public User login(String email) {
		return repo.fetchUserByEmail(email);
	}

	public User fetchById(int id) {
		Optional<User> opt = repo.findById(id);
		if (opt.isPresent()) {
			return opt.get();
		} else {
			return null;
		}
	}

	public User updateUser(User user) {
		Optional<User> opt = repo.findById(user.getId());
		if (opt.isPresent()) {
			User db = opt.get();
			if (user.getFirstName() == null) {
				user.setFirstName(db.getFirstName());
			}
			if (user.getLastName() == null) {
				user.setLastName(db.getLastName());
			}
			if (user.getEmail() == null) {
				user.setEmail(db.getEmail());
			}
			if (user.getPassword() == null) {
				user.setPassword(db.getPassword());
			}
			if (user.getPhone() == 0) {
				user.setPhone(db.getPhone());
			}
			if (user.getAge() == 0) {
				user.setAge(db.getAge());
			}
			if (user.getAddress() == null) {
				user.setAddress(db.getAddress());
			} else {
				if (user.getAddress().getId() == 0) {
					user.getAddress().setId(db.getAddress().getId());
				}
				user.setAddress(dao.updateAddress(user.getAddress()));

//				if (user.getAddress().getHouseNum() == null) {
//					user.getAddress().setHouseNum(db.getAddress().getHouseNum());
//				}
//				if (user.getAddress().getStreet() == null) {
//					user.getAddress().setStreet(db.getAddress().getStreet());
//				}
//				if (user.getAddress().getLandmMark() == null) {
//					user.getAddress().setLandmMark(db.getAddress().getLandmMark());
//				}
//				if (user.getAddress().getMandal() == null) {
//					user.getAddress().setMandal(db.getAddress().getMandal());
//				}
//				if (user.getAddress().getDistrict() == null) {
//					user.getAddress().setDistrict(db.getAddress().getDistrict());
//				}
//				if (user.getAddress().getState() == null) {
//					user.getAddress().setState(db.getAddress().getState());
//				}
//				if (user.getAddress().getPinCode() == 0) {
//					user.getAddress().setPinCode(db.getAddress().getPinCode());
//				}

			}
			if (user.getGender() == null) {
				user.setGender(db.getGender());
			}
			if (user.getType() == null) {
				user.setType(db.getType());
			}
			return repo.save(user);
		} else {
			return null;
		}
	}

	public User deleteById(int id) {
		Optional<User> opt = repo.findById(id);
		if (opt.isPresent()) {
			repo.deleteById(id);
			return opt.get();
		} else {
			return null;
		}
	}

	public List<User> fetchAll() {
		return repo.findAll();
	}

}
