package com.jsp.agro.dao;

import java.util.List;
import java.util.Optional;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;
import com.jsp.agro.entity.ProfilePhoto;
import com.jsp.agro.repo.ProfilePhotoRepo;

@Repository
public class ProfileDao {
	
	@Autowired
	private ProfilePhotoRepo repo;
	
	public ProfilePhoto saveImage(ProfilePhoto profile) {
		return repo.save(profile);
	}
	
	public ProfilePhoto fetchPhoto(int id) {
		Optional<ProfilePhoto> db = repo.findById(id);
		if(db.isPresent()) {
			return db.get();
		}else {
			return null;
		}
	}
	
	public ProfilePhoto updateProfile(ProfilePhoto profile) {
		Optional<ProfilePhoto> opt = repo.findById(profile.getId());
		if(opt.isPresent()) {
			ProfilePhoto db = opt.get();
			if(profile.getId()==0) {
				profile.setId(db.getId());
			}
			if(profile.getName()==null) {
				profile.setName(db.getName());
			}
			if(profile.getImage()==null) {
				profile.setImage(db.getImage());
			}
			return repo.save(profile);
		}else {
			return null;
		}
	}
	
	public ProfilePhoto deleteProfilePic(int id) {
		Optional<ProfilePhoto> opt = repo.findById(id);
		if(opt.isPresent()) {
			repo.deleteById(id);
			return opt.get();
		}else {
			return null;
		}
	}
	
	public List<ProfilePhoto> fetchAllProfiles(){
		return repo.findAll();
	}

}
